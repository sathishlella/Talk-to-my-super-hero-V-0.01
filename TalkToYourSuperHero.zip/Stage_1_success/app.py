from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
from gtts import gTTS
import pyttsx3
import os

app = Flask(__name__, static_url_path='/static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/speech_to_text', methods=['GET'])
def speech_to_text():
	engine = pyttsx3.init()
	r = sr.Recognizer()
	with sr.Microphone() as source:
		print("Say something:")
		audio = r.listen(source)
	try:
		text = r.recognize_google(audio)
		engine.say(text)
		engine.runAndWait()
		return jsonify({'text': text})
	except sr.UnknownValueError:
		return jsonify({'text': "Sorry, I couldn't understand your speech."})
	except sr.RequestError:
		return jsonify({'text': "I'm having trouble with my speech recognition service."})

@app.route('/text_to_speech', methods=['POST'])
def text_to_speech():
	data = request.get_json()
	text = data['text']

	engine = pyttsx3.init() 
	voices = engine.getProperty('voices')
	engine.setProperty('voice', voices[0].id)
	engine.say(text)
	engine.runAndWait()
	return jsonify({'message': 'Text converted to speech successfully'})

if __name__ == '__main__':
    app.run(debug=True)
