from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
from gtts import gTTS
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/speech_to_text', methods=['GET'])
def speech_to_text():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something:")
        audio = r.listen(source)
    
    try:
        text = r.recognize_google(audio)
        return jsonify({'text': text})
    except sr.UnknownValueError:
        return jsonify({'text': "Sorry, I couldn't understand your speech."})
    except sr.RequestError:
        return jsonify({'text': "I'm having trouble with my speech recognition service."})

@app.route('/text_to_speech', methods=['POST'])
def text_to_speech():
    data = request.get_json()
    text = data['text']
    
    tts = gTTS(text)
    tts.save("output.mp3")
    os.system("mpg321 output.mp3")  # Linux command to play the audio file
    
    return jsonify({'message': 'Text converted to speech successfully'})

if __name__ == '__main__':
    app.run(debug=True)
